$(function(){
    var documentHeight = $(document).height();
    $('.f_footer-box').css('top',documentHeight+100)
});